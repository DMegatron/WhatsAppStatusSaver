package com.example.statussaver

import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("status_saver", MODE_PRIVATE) }
    private var statusTree: Uri? = null
    private val checkboxes = linkedMapOf<Uri, CheckBox>()
    private lateinit var listContainer: LinearLayout
    private lateinit var statusLabel: TextView

    private val chooseFolder = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 16, 22)
        window.navigationBarColor = Color.rgb(15, 16, 22)
        window.decorView.systemUiVisibility = 0
        statusTree = prefs.getString("tree_uri", null)?.let(Uri::parse)
        buildUi()
        refreshList()
        if (statusTree == null) {
            statusLabel.text = "Choose the WhatsApp .Statuses folder to begin."
        }
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(12))
            setBackgroundColor(Color.rgb(15, 16, 22))
        }
        setContentView(outer)

        outer.addView(TextView(this).apply {
            text = "Status Saver"
            textSize = 27f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        outer.addView(TextView(this).apply {
            text = "Save WhatsApp photos and videos to your phone"
            textSize = 14f
            setTextColor(Color.rgb(174, 177, 194))
            setPadding(0, dp(5), 0, dp(16))
        })

        addButton(outer, "Choose WhatsApp Status Folder", true) { pickFolder() }
        addButton(outer, "Refresh", false) { refreshList() }

        statusLabel = TextView(this).apply {
            text = "Select statuses to save."
            textSize = 13f
            setTextColor(Color.rgb(174, 177, 194))
            setPadding(0, dp(12), 0, dp(8))
        }
        outer.addView(statusLabel)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        addButton(actions, "Save selected", true, weight = 1f) { saveSelected() }
        addButton(actions, "Save all", false, weight = 1f) { saveAll() }
        outer.addView(actions)

        val scroll = ScrollView(this)
        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        scroll.addView(listContainer)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        outer.addView(TextView(this).apply {
            text = "Files stay on this device. No uploads or account login."
            textSize = 11f
            setTextColor(Color.rgb(130, 134, 152))
            setPadding(0, dp(8), 0, 0)
        })
    }

    private fun addButton(
        parent: LinearLayout,
        label: String,
        primary: Boolean,
        weight: Float = 0f,
        action: () -> Unit
    ) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                if (primary) Color.rgb(88, 86, 214) else Color.rgb(43, 46, 60)
            ))
            setOnClickListener { action() }
        }
        val params = if (weight > 0f) {
            LinearLayout.LayoutParams(0, dp(48), weight).apply {
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
        } else {
            LinearLayout.LayoutParams(-1, dp(48)).apply {
                setMargins(0, dp(3), 0, dp(3))
            }
        }
        parent.addView(button, params)
    }

    private fun pickFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, chooseFolder)
    }

    @Deprecated("Uses document-tree picker for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != chooseFolder || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val flags = data.flags and
            (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        try {
            contentResolver.takePersistableUriPermission(uri, flags)
        } catch (_: SecurityException) {
            // Some providers grant read-only access; reading is sufficient.
        }
        statusTree = uri
        prefs.edit().putString("tree_uri", uri.toString()).apply()
        refreshList()
    }

    private fun refreshList() {
        checkboxes.clear()
        listContainer.removeAllViews()
        val tree = statusTree
        if (tree == null) {
            statusLabel.text = "Choose the WhatsApp .Statuses folder to begin."
            return
        }

        val root = DocumentFile.fromTreeUri(this, tree)
        if (root == null || !root.canRead()) {
            statusLabel.text = "Folder access unavailable. Choose the folder again."
            return
        }

        val media = root.listFiles()
            .filter { it.isFile && isSupported(it.name ?: "") }
            .sortedByDescending { it.lastModified() }

        statusLabel.text = "${media.size} image/video file(s) found. Select files, then save."
        if (media.isEmpty()) {
            addEmptyMessage("No supported media found. Confirm you selected the .Statuses folder and that WhatsApp has loaded statuses.")
            return
        }

        media.forEach { file ->
            val name = file.name ?: "Unnamed status"
            val type = if (name.substringAfterLast('.', "").lowercase() in listOf("mp4", "3gp", "webm", "mkv")) "VIDEO" else "IMAGE"
            val check = CheckBox(this).apply {
                text = "$type  ·  $name\n${formatBytes(file.length())}"
                textSize = 13f
                setTextColor(Color.rgb(236, 237, 244))
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(145, 143, 255))
                setPadding(dp(4), dp(7), dp(4), dp(7))
            }
            checkboxes[file.uri] = check
            listContainer.addView(check, LinearLayout.LayoutParams(-1, -2))
            val divider = View(this).apply { setBackgroundColor(Color.rgb(43, 46, 60)) }
            listContainer.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun saveSelected() {
        val selected = checkboxes.filterValues { it.isChecked }.keys.toList()
        if (selected.isEmpty()) {
            toast("Select at least one status.")
            return
        }
        saveUris(selected)
    }

    private fun saveAll() {
        if (checkboxes.isEmpty()) {
            toast("No statuses to save.")
            return
        }
        saveUris(checkboxes.keys.toList())
    }

    private fun saveUris(uris: List<Uri>) {
        var saved = 0
        var skipped = 0
        var failed = 0
        uris.forEach { uri ->
            try {
                val doc = DocumentFile.fromSingleUri(this, uri)
                val originalName = doc?.name ?: "status_${System.currentTimeMillis()}"
                val mime = contentResolver.getType(uri) ?: mimeFor(originalName)
                if (copyToPictures(uri, originalName, mime)) saved++ else skipped++
            } catch (_: Exception) {
                failed++
            }
        }
        toast("Saved: $saved · Already present: $skipped · Failed: $failed")
        refreshList()
    }

    private fun copyToPictures(source: Uri, originalName: String, mime: String): Boolean {
        val safeName = originalName.replace(Regex("[^A-Za-z0-9._ -]"), "_")
        val resolver = contentResolver
        val collection = if (mime.startsWith("video/")) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }

        // Avoid duplicate copies by display name within the app's destination folder.
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.DISPLAY_NAME}=?"
        val args = arrayOf("Pictures/WhatsApp Statuses/", safeName)
        resolver.query(collection, projection, selection, args, null)?.use { cursor ->
            if (cursor.moveToFirst()) return false
        }

        val values = android.content.ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/WhatsApp Statuses")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val target = resolver.insert(collection, values) ?: throw IOException("Unable to create destination")
        try {
            resolver.openInputStream(source).use { input ->
                if (input == null) throw IOException("Cannot read source")
                resolver.openOutputStream(target, "w").use { output ->
                    if (output == null) throw IOException("Cannot write destination")
                    input.copyTo(output)
                }
            }
            val done = android.content.ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
            }
            resolver.update(target, done, null, null)
            return true
        } catch (e: Exception) {
            resolver.delete(target, null, null)
            throw e
        }
    }

    private fun isSupported(name: String): Boolean {
        return name.substringAfterLast('.', "").lowercase() in
            setOf("jpg", "jpeg", "png", "webp", "gif", "mp4", "3gp", "webm", "mkv")
    }

    private fun mimeFor(name: String): String =
        when (name.substringAfterLast('.', "").lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "mp4" -> "video/mp4"
            "3gp" -> "video/3gpp"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            else -> "application/octet-stream"
        }

    private fun formatBytes(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format(Locale.getDefault(), "%.0f KB", bytes / 1024.0)
        else -> String.format(Locale.getDefault(), "%.1f MB", bytes / (1024.0 * 1024.0))
    }

    private fun formatDate(timestamp: Long): String =
        SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(timestamp))

    private fun addEmptyMessage(message: String) {
        listContainer.addView(TextView(this).apply {
            text = message
            textSize = 14f
            setTextColor(Color.rgb(174, 177, 194))
            setPadding(dp(8), dp(20), dp(8), dp(20))
        })
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
